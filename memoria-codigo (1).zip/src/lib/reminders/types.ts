export const VIEW_IDS = ["today", "upcoming", "overdue", "completed", "all"] as const;
export type ViewId = (typeof VIEW_IDS)[number];

export const PRIORITIES = ["low", "medium", "high"] as const;
export type Priority = (typeof PRIORITIES)[number];

export const PALETTE_IDS = [
  "ink",
  "slate",
  "sage",
  "olive",
  "clay",
  "cocoa",
  "rose",
  "storm",
] as const;
export type PaletteId = (typeof PALETTE_IDS)[number];

export type Category = {
  id: string;
  name: string;
  color: PaletteId;
  parentId: string | null;
  x?: number;
  y?: number;
  image?: string;
};

export type ReminderMedia = {
  id: string;
  kind: "photo" | "video" | "voice";
  name: string;
  mime: string;
  src: string;
};

export type Reminder = {
  id: string;
  title: string;
  notes: string;
  categoryId: string;
  dueAt: string;
  completedAt: string | null;
  priority: Priority;
  createdAt: string;
  notifiedAt: string | null;
  media: ReminderMedia[];
};

export type ReminderDraft = {
  title: string;
  notes: string;
  categoryId: string;
  dueAt: string;
  priority: Priority;
  media: ReminderMedia[];
};
