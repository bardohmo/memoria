import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { swatch } from "@/lib/reminders/palette";
import { categoryCount, childrenOf, counts, roots, VIEW_LABELS } from "@/lib/reminders/query";
import { useReminderStore } from "@/lib/reminders/store";
import { VIEW_IDS, type Category } from "@/lib/reminders/types";

type Props = {
  onNewCategory: () => void;
  onEditCategory: (category: Category) => void;
  onNavigate?: () => void;
};

export function NavPanel({ onNewCategory, onEditCategory, onNavigate }: Props) {
  const reminders = useReminderStore((s) => s.reminders);
  const categories = useReminderStore((s) => s.categories);
  const view = useReminderStore((s) => s.view);
  const categoryId = useReminderStore((s) => s.categoryId);
  const setView = useReminderStore((s) => s.setView);
  const setCategoryId = useReminderStore((s) => s.setCategoryId);
  const viewCounts = counts(reminders);

  function pick(next: () => void) {
    next();
    onNavigate?.();
  }

  return (
    <div className="flex min-h-0 flex-col pb-8">
      <div className="px-1 pb-6">
        <p className="font-display text-2xl font-semibold tracking-tight">Memoria</p>
        <p className="mt-1 text-sm text-muted-foreground">Recordatorios para una vida más clara.</p>
      </div>

      <p className="px-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        Vistas
      </p>
      <nav className="mt-2 flex flex-col gap-1" aria-label="Vistas">
        {VIEW_IDS.map((id) => {
          const active = view === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => pick(() => setView(id))}
              className={cn(
                "flex h-11 items-center justify-between rounded-md px-3 text-sm font-medium",
                "transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-muted",
              )}
            >
              {VIEW_LABELS[id]}
              <span className="tabular-nums text-xs opacity-80">{viewCounts[id]}</span>
            </button>
          );
        })}
      </nav>

      <div className="mt-6 flex items-center justify-between px-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Categorías
        </p>
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          onClick={onNewCategory}
          aria-label="Nueva categoría"
        >
          <Plus />
        </Button>
      </div>
      <nav className="mt-2 flex flex-col gap-1" aria-label="Categorías">
        <button
          type="button"
          onClick={() => pick(() => setCategoryId(null))}
          className={cn(
            "flex h-11 items-center justify-between rounded-md px-3 text-sm font-medium",
            "transition-[background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
            categoryId === null ? "bg-card shadow-card" : "hover:bg-muted",
          )}
        >
          Todas
        </button>
        {roots(categories).map((c) => {
          const kids = childrenOf(categories, c.id);
          const active = categoryId === c.id;
          return (
            <div key={c.id} className="flex flex-col gap-1">
              <button
                type="button"
                onClick={() => pick(() => setCategoryId(c.id))}
                onDoubleClick={() => onEditCategory(c)}
                className={cn(
                  "flex h-11 items-center justify-between rounded-md px-3 text-sm font-medium",
                  active ? "bg-card shadow-card" : "hover:bg-muted",
                )}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <span
                    className="size-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: swatch(c.color) }}
                  />
                  <span className="truncate">{c.name}</span>
                </span>
                <span className="tabular-nums text-xs text-muted-foreground">
                  {categoryCount(reminders, categories, c.id)}
                </span>
              </button>
              {kids.map((kid) => (
                <button
                  key={kid.id}
                  type="button"
                  onClick={() => pick(() => setCategoryId(kid.id))}
                  onDoubleClick={() => onEditCategory(kid)}
                  className={cn(
                    "ml-5 flex h-10 items-center justify-between rounded-md px-3 text-sm",
                    categoryId === kid.id ? "bg-card shadow-card" : "hover:bg-muted",
                  )}
                >
                  <span className="truncate">{kid.name}</span>
                  <span className="tabular-nums text-xs text-muted-foreground">
                    {categoryCount(reminders, categories, kid.id)}
                  </span>
                </button>
              ))}
            </div>
          );
        })}
      </nav>
    </div>
  );
}
