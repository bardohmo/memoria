import { useEffect, useState } from "react";
import { Bell, BellOff } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { isOverdue } from "@/lib/reminders/dates";
import { useReminderStore } from "@/lib/reminders/store";

function permission(): NotificationPermission | "unsupported" {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  return Notification.permission;
}

export function NotificationBell() {
  const [status, setStatus] = useState<NotificationPermission | "unsupported">("denied");
  const reminders = useReminderStore((s) => s.reminders);
  const markNotified = useReminderStore((s) => s.markNotified);

  useEffect(() => {
    setStatus(permission());
  }, []);

  useEffect(() => {
    const tick = () => {
      const now = Date.now();
      const store = useReminderStore.getState();
      for (const reminder of store.reminders) {
        if (reminder.completedAt || reminder.notifiedAt) continue;
        const due = new Date(reminder.dueAt).getTime();
        if (due > now) continue;
        if (now - due > 2 * 60 * 1000) continue;
        store.markNotified(reminder.id);
        toast(reminder.title, { description: "Es hora de este recordatorio." });
        if (permission() === "granted") {
          try {
            new Notification(reminder.title, {
              body: reminder.notes || "Es hora de este recordatorio.",
              tag: reminder.id,
            });
          } catch {
            /* preview hosts may block Notification constructors */
          }
        }
      }
    };
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, [markNotified]);

  const overdueNow = reminders.filter((r) => isOverdue(r.dueAt, r.completedAt)).length;

  async function enable() {
    if (status === "unsupported" || status === "granted") {
      if (overdueNow > 0) toast(`Tienes ${overdueNow} aviso${overdueNow === 1 ? "" : "s"} atrasado${overdueNow === 1 ? "" : "s"}`);
      return;
    }
    try {
      const next = await Notification.requestPermission();
      setStatus(next);
      if (next === "granted") toast("Avisos del navegador activados");
    } catch {
      setStatus("denied");
    }
  }

  const label =
    status === "granted" || status === "unsupported"
      ? overdueNow
        ? `${overdueNow} atrasados`
        : "Avisos activos"
      : "Activar avisos";

  return (
    <Button
      variant="ghost"
      size="icon"
      className="hud-quiet relative"
      onClick={() => void enable()}
      aria-label={label}
    >
      {status === "granted" ? <Bell /> : <BellOff />}
      {overdueNow > 0 ? <span className="mind-hud-badge">{overdueNow}</span> : null}
    </Button>
  );
}
