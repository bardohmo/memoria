import { useEffect, useMemo, useRef, useState, type CSSProperties, type MouseEvent, type PointerEvent, type ReactNode } from "react";
import { Plus } from "lucide-react";
import { dayLabel, isOverdue, timeLabel } from "@/lib/reminders/dates";
import {
  categoryCount,
  childrenOf,
  findCategory,
  matchesView,
  roots,
} from "@/lib/reminders/query";
import type { Category, Reminder, ViewId } from "@/lib/reminders/types";
import { cn } from "@/lib/utils";

type Props = {
  categories: Category[];
  reminders: Reminder[];
  selectedId: string | null;
  expanded: boolean;
  view: ViewId;
  onToggle: () => void;
  onSelect: (id: string | null) => void;
  onOpenReminder: (reminder: Reminder) => void;
  onCreate: () => void;
  onMove: (id: string, x: number, y: number) => void;
  children?: ReactNode;
};

type Pt = { x: number; y: number };

const CENTER: Pt = { x: 50, y: 50 };
const HOLD_MS = 280;

const LOBES: Record<string, Pt> = {
  "cat-personal": { x: 32, y: 30 },
  "cat-trabajo": { x: 68, y: 31 },
  "cat-salud": { x: 33, y: 68 },
  "cat-casa": { x: 67, y: 69 },
};

const MAX_LEAVES = 5;

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function clampPos(p: Pt): Pt {
  return { x: clamp(p.x, 14, 86), y: clamp(p.y, 18, 84) };
}

function polar(cx: number, cy: number, r: number, angle: number): Pt {
  return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
}

function orbitSlot(index: number, total: number, spin: number, box: { w: number; h: number }): Pt {
  const angle = -Math.PI / 2 + (2 * Math.PI * index) / Math.max(total, 1) + spin;
  const radius = Math.min(box.w, box.h) * 0.36;
  return {
    x: 50 + ((radius * Math.cos(angle)) / Math.max(box.w, 1)) * 100,
    y: 50 + ((radius * Math.sin(angle)) / Math.max(box.h, 1)) * 100,
  };
}

function colorArc(index: number, total: number, radius = 42): { d: string; tip: Pt } {
  const slice = (2 * Math.PI) / Math.max(total, 1);
  const start = -Math.PI / 2 + slice * index + slice * 0.12;
  const end = start + slice * 0.62;
  const tip = { x: 50 + radius * Math.cos(start), y: 50 + radius * Math.sin(start) };
  const x2 = 50 + radius * Math.cos(end);
  const y2 = 50 + radius * Math.sin(end);
  return {
    d: `M ${tip.x.toFixed(2)} ${tip.y.toFixed(2)} A ${radius} ${radius} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`,
    tip,
  };
}

function rootPos(category: Category, index: number, total: number): Pt {
  return LOBES[category.id] ?? polar(50, 50, 28, -Math.PI / 2 + (2 * Math.PI * index) / Math.max(total, 1));
}

function placed(category: Category, fallback: Pt, live: (Pt & { id: string }) | null): Pt {
  if (live?.id === category.id) return { x: live.x, y: live.y };
  if (typeof category.x === "number" && typeof category.y === "number") {
    return { x: category.x, y: category.y };
  }
  return fallback;
}

function hasCustom(category: Category, live: (Pt & { id: string }) | null) {
  return live?.id === category.id || (typeof category.x === "number" && typeof category.y === "number");
}

function orbitAway(origin: Pt, count: number): Pt[] {
  if (count <= 0) return [];
  const spacing = count > 3 ? 14 : 18;
  const lift = origin.y >= 50 ? -22 : 22;
  const start = origin.x - ((count - 1) * spacing) / 2;
  return Array.from({ length: count }, (_, i) =>
    clampPos({ x: start + i * spacing, y: origin.y + lift }),
  );
}

function stackTop(count: number): Pt[] {
  if (count <= 0) return [];
  const startY = 17.4;
  const gapY = count > 4 ? 10.4 : 11.2;
  if (count <= 2) {
    return Array.from({ length: count }, (_, i) => ({ x: 50, y: startY + i * gapY }));
  }
  const xs = [26.5, 73.5] as const;
  return Array.from({ length: count }, (_, i) => {
    const lastAlone = count % 2 === 1 && i === count - 1;
    return {
      x: lastAlone ? 50 : xs[i % 2],
      y: startY + Math.floor(i / 2) * gapY,
    };
  });
}

type Box = { w: number; h: number; rem: number };

const NODE_GAP = 14;

function pctToPx(p: Pt, box: Box) {
  return { x: (p.x / 100) * box.w, y: (p.y / 100) * box.h };
}

function pxToPct(x: number, y: number, box: Box): Pt {
  return clampPos({
    x: (x / Math.max(box.w, 1)) * 100,
    y: (y / Math.max(box.h, 1)) * 100,
  });
}

function keepClear(
  pos: Pt,
  selfRem: number,
  others: { pos: Pt; rRem: number }[],
  nucleusDrawem: number,
  box: Box,
): Pt {
  let { x, y } = pctToPx(pos, box);
  const self = selfRem * box.rem;
  const cx = (CENTER.x / 100) * box.w;
  const cy = (CENTER.y / 100) * box.h;
  const minNucleus = nucleusDrawem * box.rem + self + NODE_GAP;
  const minX = 0.14 * box.w;
  const maxX = 0.86 * box.w;
  const minY = 0.18 * box.h;
  const maxY = 0.84 * box.h;

  for (let i = 0; i < 12; i++) {
    let dx = x - cx;
    let dy = y - cy;
    let dist = Math.hypot(dx, dy);
    if (dist < 0.001) {
      dx = 0;
      dy = -1;
      dist = 1;
    }
    if (dist < minNucleus) {
      const push = minNucleus - dist;
      x += (dx / dist) * push;
      y += (dy / dist) * push;
    }
    for (const other of others) {
      const o = pctToPx(other.pos, box);
      const minD = self + other.rRem * box.rem + NODE_GAP;
      dx = x - o.x;
      dy = y - o.y;
      dist = Math.hypot(dx, dy);
      if (dist < 0.001) {
        dx = 1;
        dy = 0;
        dist = 1;
      }
      if (dist < minD) {
        const push = minD - dist;
        x += (dx / dist) * push;
        y += (dy / dist) * push;
      }
    }
    x = Math.min(maxX, Math.max(minX, x));
    y = Math.min(maxY, Math.max(minY, y));
  }
  return pxToPct(x, y, box);
}

function dock(from: Pt, to: Pt, startRem: number, endRem: number, box: Box): { a: Pt; b: Pt } {
  const px = ((to.x - from.x) / 100) * box.w;
  const py = ((to.y - from.y) / 100) * box.h;
  const len = Math.hypot(px, py) || 1;
  const sr = Math.min(startRem * box.rem, len * 0.42);
  const er = Math.min(endRem * box.rem, len * 0.42);
  return {
    a: {
      x: from.x + ((px / len) * sr * 100) / box.w,
      y: from.y + ((py / len) * sr * 100) / box.h,
    },
    b: {
      x: to.x - ((px / len) * er * 100) / box.w,
      y: to.y - ((py / len) * er * 100) / box.h,
    },
  };
}

function axon(from: Pt, to: Pt, startRem: number, endRem: number, box: Box): string {
  const { a, b } = dock(from, to, startRem, endRem, box);
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const c1x = a.x + dx * 0.32 - dy * 0.09;
  const c1y = a.y + dy * 0.32 + dx * 0.09;
  const c2x = a.x + dx * 0.8;
  const c2y = a.y + dy * 0.8;
  return `M ${a.x.toFixed(2)} ${a.y.toFixed(2)} C ${c1x.toFixed(2)} ${c1y.toFixed(2)} ${c2x.toFixed(2)} ${c2y.toFixed(2)} ${b.x.toFixed(2)} ${b.y.toFixed(2)}`;
}

function tip(from: Pt, to: Pt, startRem: number, endRem: number, box: Box): Pt {
  return dock(from, to, startRem, endRem, box).b;
}

function nodeVars(pos: Pt, i: number, color: string, origin: Pt = CENTER): CSSProperties {
  return {
    "--x": `${pos.x}%`,
    "--y": `${pos.y}%`,
    "--ox": `${origin.x}%`,
    "--oy": `${origin.y}%`,
    "--i": i,
    "--node": `var(--cat-${color})`,
  } as CSSProperties;
}

type Session = {
  id: string;
  pointerId: number;
  armed: boolean;
  moved: boolean;
  startX: number;
  startY: number;
  timer: number;
};

export function ClusterMap({
  categories,
  reminders,
  selectedId,
  expanded,
  view,
  onToggle,
  onSelect,
  onOpenReminder,
  onCreate,
  onMove,
  children,
}: Props) {
  const [reduced, setReduced] = useState(false);
  const [live, setLive] = useState<(Pt & { id: string }) | null>(null);
  const [holding, setHolding] = useState<string | null>(null);
  const [canvas, setCanvas] = useState({ w: 390, h: 844 });
  const [snap, setSnap] = useState(false);
  const [leavesReady, setLeavesReady] = useState(false);
  const [brainLit, setBrainLit] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  const session = useRef<Session | null>(null);
  const skipClick = useRef(false);
  const spinRef = useRef(0);
  const lobeRefs = useRef(new Map<string, HTMLButtonElement>());
  const topRef = useRef<Category[]>([]);
  const bodiesRef = useRef<{ id: string; pos: Pt; rRem: number }[]>([]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setReduced(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);

  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const measure = () =>
      setCanvas({ w: el.clientWidth || 390, h: el.clientHeight || 844 });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (!expanded) setSnap(false);
  }, [expanded]);

  useEffect(() => {
    if (expanded || reduced) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      spinRef.current += dt * 0.28;
      const list = topRef.current;
      list.forEach((category, i) => {
        const el = lobeRefs.current.get(category.id);
        if (!el) return;
        const pos = orbitSlot(i, list.length, spinRef.current, canvas);
        el.style.setProperty("--x", `${pos.x}%`);
        el.style.setProperty("--y", `${pos.y}%`);
      });
      frame = window.requestAnimationFrame(tick);
    };
    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [expanded, reduced, canvas]);

  const top = roots(categories);
  topRef.current = top;
  const selected = selectedId ? findCategory(categories, selectedId) : undefined;
  const selectedRoot = selected
    ? selected.parentId
      ? findCategory(categories, selected.parentId)
      : selected
    : undefined;
  const selectedIsChild = Boolean(selected?.parentId);
  const focusRootId = selectedRoot?.id ?? null;
  const subs = focusRootId ? childrenOf(categories, focusRootId) : [];
  const rootActsAsLeaf = Boolean(focusRootId) && subs.length === 0;
  const leafId = selectedIsChild ? selectedId : rootActsAsLeaf ? focusRootId : null;
  const listing = Boolean(leafId);

  useEffect(() => {
    setLeavesReady(false);
    if (!leafId) return;
    const timer = window.setTimeout(() => setLeavesReady(true), 480);
    return () => window.clearTimeout(timer);
  }, [leafId]);

  const rem =
    typeof document === "undefined"
      ? 16
      : parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  const box: Box = { w: canvas.w, h: canvas.h, rem };
  const nucleusDraw = (expanded ? 3.55 : 6.6) / 2;
  const nucleusHit = nucleusDraw + 0.6;
  const lobeR = 3.75 / 2;
  const subR = 2.55 / 2;
  const leafR = 1.45;

  const rootPositions = useMemo(() => {
    const list = roots(categories);
    if (!expanded) {
      return new Map(
        list.map((category, i) => [category.id, orbitSlot(i, list.length, spinRef.current, canvas)] as const),
      );
    }
    const raw = list.map((category, i) => {
      const base = placed(category, rootPos(category, i, list.length), live);
      const custom = hasCustom(category, live);
      const parked =
        listing && !custom ? clampPos({ x: base.x, y: base.y + 10 }) : base;
      return { id: category.id, pos: parked };
    });
    const settled: { id: string; pos: Pt }[] = [];
    for (const node of raw) {
      const others = [
        ...settled.map((item) => ({ pos: item.pos, rRem: lobeR })),
        ...bodiesRef.current
          .filter((body) => body.id !== node.id && !raw.some((r) => r.id === body.id))
          .map((body) => ({ pos: body.pos, rRem: body.rRem })),
      ];
      settled.push({
        id: node.id,
        pos: keepClear(node.pos, lobeR, others, nucleusHit, box),
      });
    }
    return new Map(settled.map((node) => [node.id, node.pos] as const));
  }, [categories, live, listing, expanded, canvas, box.w, box.h, box.rem, nucleusHit, lobeR]);

  const focusPos = focusRootId ? (rootPositions.get(focusRootId) ?? CENTER) : CENTER;
  const subPositions = useMemo(() => {
    const parked = subs.length ? orbitAway(focusPos, subs.length) : [];
    const raw = subs.map((sub, i) => placed(sub, parked[i] ?? CENTER, live));
    const rootBodies = [...rootPositions.entries()].map(([, pos]) => ({ pos, rRem: lobeR }));
    const settled: Pt[] = [];
    raw.forEach((pos, i) => {
      const others = [
        ...rootBodies,
        ...settled.map((item) => ({ pos: item, rRem: subR })),
      ];
      settled.push(keepClear(pos, subR, others, nucleusHit, box));
    });
    return settled;
  }, [subs, focusPos, live, rootPositions, lobeR, subR, nucleusHit, box.w, box.h, box.rem]);

  const leafReminders = useMemo(() => {
    if (!leafId) return [];
    return reminders
      .filter((r) => r.categoryId === leafId)
      .filter((r) => (view === "all" ? true : matchesView(r, view)))
      .sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime())
      .slice(0, MAX_LEAVES);
  }, [reminders, leafId, view]);

  const leafParentPos = useMemo(() => {
    if (!leafId) return focusPos;
    if (rootActsAsLeaf) return focusPos;
    const idx = subs.findIndex((s) => s.id === leafId);
    return subPositions[idx] ?? focusPos;
  }, [leafId, rootActsAsLeaf, focusPos, subs, subPositions]);

  const leafPositions = useMemo(
    () => stackTop(leafReminders.length),
    [leafReminders.length],
  );

  const showGhost = Boolean(leafId) && leafReminders.length === 0;
  const ghostPos = showGhost ? stackTop(1)[0] : null;
  const leafCat = leafId ? findCategory(categories, leafId) : undefined;

  bodiesRef.current = [
    ...top.map((category) => ({
      id: category.id,
      pos: rootPositions.get(category.id) ?? CENTER,
      rRem: lobeR,
    })),
    ...subs.map((sub, i) => ({
      id: sub.id,
      pos: subPositions[i] ?? CENTER,
      rRem: subR,
    })),
  ];

  function clientToPct(clientX: number, clientY: number): Pt {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return CENTER;
    return clampPos({
      x: ((clientX - rect.left) / rect.width) * 100,
      y: ((clientY - rect.top) / rect.height) * 100,
    });
  }

  function fitNode(id: string, raw: Pt): Pt {
    const self = bodiesRef.current.find((body) => body.id === id);
    const selfRem = self?.rRem ?? lobeR;
    const others = bodiesRef.current
      .filter((body) => body.id !== id)
      .map((body) => ({ pos: body.pos, rRem: body.rRem }));
    return keepClear(raw, selfRem, others, nucleusHit, box);
  }

  function clearSession() {
    if (session.current?.timer) window.clearTimeout(session.current.timer);
    session.current = null;
    setHolding(null);
  }

  function bindDrag(id: string, onTap: () => void) {
    return {
      onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
        if (e.button !== 0 || !expanded) return;
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        if (session.current?.timer) window.clearTimeout(session.current.timer);
        const timer = window.setTimeout(() => {
          const s = session.current;
          if (!s || s.id !== id) return;
          s.armed = true;
          setHolding(id);
          try {
            navigator.vibrate?.(12);
          } catch {
            /* preview hosts may block vibrate */
          }
        }, HOLD_MS);
        session.current = {
          id,
          pointerId: e.pointerId,
          armed: false,
          moved: false,
          startX: e.clientX,
          startY: e.clientY,
          timer,
        };
      },
      onPointerMove: (e: PointerEvent<HTMLButtonElement>) => {
        const s = session.current;
        if (!s || s.id !== id || s.pointerId !== e.pointerId) return;
        if (!s.armed) return;
        const dist = Math.hypot(e.clientX - s.startX, e.clientY - s.startY);
        if (dist < 6 && !s.moved) return;
        s.moved = true;
        skipClick.current = true;
        e.preventDefault();
        setLive({ id, ...fitNode(id, clientToPct(e.clientX, e.clientY)) });
      },
      onPointerUp: (e: PointerEvent<HTMLButtonElement>) => {
        const s = session.current;
        if (!s || s.id !== id) return;
        const moved = s.moved;
        window.clearTimeout(s.timer);
        session.current = null;
        setHolding(null);
        try {
          e.currentTarget.releasePointerCapture(e.pointerId);
        } catch {
          /* already released */
        }
        if (moved) {
          skipClick.current = true;
          const pt = fitNode(id, clientToPct(e.clientX, e.clientY));
          onMove(id, pt.x, pt.y);
          setLive(null);
          return;
        }
        skipClick.current = true;
        onTap();
      },
      onPointerCancel: () => {
        clearSession();
        setLive(null);
      },
      onClick: (e: MouseEvent<HTMLButtonElement>) => {
        if (skipClick.current) {
          skipClick.current = false;
          e.preventDefault();
          e.stopPropagation();
          return;
        }
        onTap();
      },
    };
  }

  function sparkBrain() {
    setBrainLit(false);
    window.requestAnimationFrame(() => setBrainLit(true));
  }

  const draggingId = live?.id ?? holding;

  return (
    <div className={cn("mind-stage", expanded && "is-open", !expanded && "is-orbit", snap && "is-snap", focusRootId && "is-focused", listing && "is-listing")}>
      <div ref={canvasRef} className="mind-canvas">
        <span className="mind-vignette" aria-hidden />
        <span className="mind-wash" aria-hidden />

        <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="mind-rings" aria-hidden>
          <g className="live-rings">
            <circle cx="50" cy="50" r="46" className="halo-ring static" />
            {top.map((category, i) => {
              const arc = colorArc(i, top.length);
              return (
                <g key={category.id}>
                  <path d={arc.d} className="cat-arc" stroke={`var(--cat-${category.color})`} />
                  <circle
                    cx={arc.tip.x}
                    cy={arc.tip.y}
                    r="1.7"
                    className="cat-dot"
                    fill={`var(--cat-${category.color})`}
                  />
                </g>
              );
            })}
          </g>
        </svg>

        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="mind-svg" aria-hidden>
          <defs>
            <filter id="neural-glow" x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur stdDeviation="0.55" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {expanded
            ? top.map((category, i) => {
                const pos = rootPositions.get(category.id);
                if (!pos) return null;
                const dimmed = Boolean(focusRootId) && focusRootId !== category.id;
                const d = axon(CENTER, pos, nucleusDraw, lobeR, box);
                const end = tip(CENTER, pos, nucleusDraw, lobeR, box);
                return (
                  <g key={category.id} opacity={dimmed ? 0.14 : 1}>
                    <path
                      d={d}
                      fill="none"
                      stroke={`var(--cat-${category.color})`}
                      strokeWidth={focusRootId === category.id ? 0.55 : 0.32}
                      filter="url(#neural-glow)"
                      className="neural-draw"
                      pathLength={1}
                      style={{ animationDelay: `${90 + i * 80}ms` }}
                    />
                    <circle
                      cx={end.x}
                      cy={end.y}
                      r={focusRootId === category.id ? 1.05 : 0.82}
                      fill={`var(--cat-${category.color})`}
                      filter="url(#neural-glow)"
                    />
                    {focusRootId === category.id || reduced ? null : (
                      <circle r="0.7" fill={`var(--cat-${category.color})`} filter="url(#neural-glow)">
                        <animateMotion dur="2.6s" repeatCount="indefinite" begin={`${i * 0.4}s`} path={d} />
                      </circle>
                    )}
                  </g>
                );
              })
            : null}

          {expanded && focusRootId
            ? subs.map((sub, i) => {
                const pos = subPositions[i];
                if (!pos) return null;
                const d = axon(focusPos, pos, lobeR, subR, box);
                const end = tip(focusPos, pos, lobeR, subR, box);
                const active = leafId === sub.id;
                return (
                  <g key={sub.id}>
                    <path
                      d={d}
                      fill="none"
                      stroke={`var(--cat-${sub.color})`}
                      strokeWidth={active ? 0.42 : 0.26}
                      filter="url(#neural-glow)"
                      className="neural-draw"
                      pathLength={1}
                      style={{ animationDelay: `${140 + i * 70}ms` }}
                    />
                    <circle
                      cx={end.x}
                      cy={end.y}
                      r={active ? 0.95 : 0.78}
                      fill={`var(--cat-${sub.color})`}
                      filter="url(#neural-glow)"
                    />
                    {reduced ? null : (
                      <circle r="0.55" fill={`var(--cat-${sub.color})`} filter="url(#neural-glow)">
                        <animateMotion
                          dur="2s"
                          repeatCount="indefinite"
                          begin={`${0.2 + i * 0.28}s`}
                          path={d}
                        />
                      </circle>
                    )}
                  </g>
                );
              })
            : null}

          {leafId && leafCat
            ? leafReminders.map((reminder, i) => {
                const pos = leafPositions[i];
                if (!pos) return null;
                const d = axon(leafParentPos, pos, subR, leafR, box);
                const end = tip(leafParentPos, pos, subR, leafR, box);
                return (
                  <g key={reminder.id}>
                    <path
                      d={d}
                      fill="none"
                      stroke={`var(--cat-${leafCat.color})`}
                      strokeWidth={0.22}
                      className="neural-draw"
                      pathLength={1}
                      style={{ animationDelay: `${180 + i * 50}ms` }}
                    />
                    <circle
                      cx={end.x}
                      cy={end.y}
                      r="0.7"
                      fill={`var(--cat-${leafCat.color})`}
                    />
                  </g>
                );
              })
            : null}
        </svg>

        <div className="mind-nodes">
        {top.map((category, i) => {
          const pos = rootPositions.get(category.id) ?? CENTER;
          const pending = categoryCount(reminders, categories, category.id);
          const active = expanded && focusRootId === category.id;
          const dimmed = expanded && Boolean(focusRootId) && !active;
          const tap = () => onSelect(active && !selectedIsChild && !rootActsAsLeaf ? null : category.id);
          return (
            <button
              key={category.id}
              ref={(el) => {
                if (el) lobeRefs.current.set(category.id, el);
                else lobeRefs.current.delete(category.id);
              }}
              type="button"
              className={cn(
                "lobe-node",
                selectedId === category.id && "is-active",
                dimmed && "is-dim",
                draggingId === category.id && "is-dragging",
              )}
              style={nodeVars(pos, i, category.color)}
              aria-pressed={active}
              aria-label={`${category.name}, ${pending} pendientes`}
              {...(expanded
                ? bindDrag(category.id, tap)
                : {
                    onPointerUp: (e: PointerEvent<HTMLButtonElement>) => {
                      if (e.button !== 0) return;
                      skipClick.current = true;
                      tap();
                    },
                    onClick: (e: MouseEvent<HTMLButtonElement>) => {
                      if (skipClick.current) {
                        skipClick.current = false;
                        e.preventDefault();
                        return;
                      }
                      tap();
                    },
                  })}
            >
              {category.image ? (
                <span className="lobe-photo" style={{ backgroundImage: `url(${category.image})` }} />
              ) : null}
              <span className="tabular-nums">{pending}</span>
              <span className="lobe-label">{category.name}</span>
            </button>
          );
        })}

        {expanded && focusRootId
          ? subs.map((sub, i) => {
              const pos = subPositions[i];
              if (!pos) return null;
              const pending = categoryCount(reminders, categories, sub.id);
              const active = leafId === sub.id;
              return (
                <button
                  key={sub.id}
                  type="button"
                  className={cn(
                    "sub-node",
                    selectedId === sub.id && "is-active",
                    Boolean(leafId) && selectedId !== sub.id && "is-quiet",
                    draggingId === sub.id && "is-dragging",
                  )}
                  style={nodeVars(pos, i, sub.color, focusPos)}
                  aria-pressed={active}
                  aria-label={`${sub.name}, ${pending} pendientes`}
                  {...bindDrag(sub.id, () => onSelect(active ? focusRootId : sub.id))}
                >
                  {sub.image ? (
                    <span className="lobe-photo" style={{ backgroundImage: `url(${sub.image})` }} />
                  ) : null}
                  <span className="tabular-nums">{pending}</span>
                  <span className="lobe-label">{sub.name}</span>
                </button>
              );
            })
          : null}

        {leafId && leafCat
          ? leafReminders.map((reminder, i) => {
              const pos = leafPositions[i];
              if (!pos) return null;
              const overdue = isOverdue(reminder.dueAt, reminder.completedAt);
              const done = Boolean(reminder.completedAt);
              return (
                <button
                  key={reminder.id}
                  type="button"
                  className={cn(
                    "leaf-node",
                    overdue && "is-overdue",
                    reminder.priority === "high" && "is-high",
                    done && "is-done",
                    !leavesReady && "is-locked",
                  )}
                  style={nodeVars(pos, i, leafCat.color, leafParentPos)}
                  onClick={() => {
                    if (!leavesReady) return;
                    onOpenReminder(reminder);
                  }}
                >
                  <span className="leaf-title">{reminder.title}</span>
                  <span className="leaf-meta">
                    {dayLabel(reminder.dueAt)} · {timeLabel(reminder.dueAt)}
                  </span>
                  <span className="leaf-status">{done ? "Atendido" : "No atendido"}</span>
                </button>
              );
            })
          : null}

        {showGhost && ghostPos && leafCat ? (
          <button
            type="button"
            className={cn("leaf-node is-ghost", !leavesReady && "is-locked")}
            style={nodeVars(ghostPos, 0, leafCat.color, leafParentPos)}
            onClick={() => {
              if (!leavesReady) return;
              onCreate();
            }}
          >
            <Plus className="size-3.5" />
            <span className="leaf-title">Nuevo aviso</span>
          </button>
        ) : null}
      </div>

      <button
        type="button"
        className={cn("mind-nucleus", expanded && "is-open", brainLit && "is-lit")}
        onPointerUp={(e) => {
          if (e.button !== 0) return;
          skipClick.current = true;
          sparkBrain();
          onToggle();
        }}
        onClick={(e) => {
          if (skipClick.current) {
            skipClick.current = false;
            e.preventDefault();
            return;
          }
          sparkBrain();
          onToggle();
        }}
        aria-expanded={expanded}
        aria-label={expanded ? "Volver a la órbita" : "Ordenar categorías"}
      >
        <img
          src="/nucleus-brain.png?v=3"
          alt=""
          className="nucleus-brain"
          onAnimationEnd={(e) => {
            if (e.animationName.includes("brain-tap")) setBrainLit(false);
          }}
        />
        <span className="brain-flash" aria-hidden />
      </button>

      {!expanded ? <p className="mind-hint">Toca el centro para ordenar</p> : null}
      </div>

      <div className="mind-chrome">{children}</div>
    </div>
  );
}
