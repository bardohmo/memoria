import { createFileRoute } from "@tanstack/react-router";
import { PhoneFrame } from "@/components/reminders/phone-frame";
import { SplashScreen } from "@/components/reminders/splash-screen";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <PhoneFrame>
      <SplashScreen />
    </PhoneFrame>
  );
}
