import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/reminders/app-shell";
import type { SplashAction } from "@/components/reminders/splash-screen";

const MODOS = ["start", "remember", "organize", "achieve"] as const;

export const Route = createFileRoute("/app")({
  validateSearch: (raw: Record<string, unknown>): { modo: SplashAction } => ({
    modo: MODOS.includes(raw.modo as SplashAction) ? (raw.modo as SplashAction) : "start",
  }),
  component: AppPage,
});

function AppPage() {
  const { modo } = Route.useSearch();
  return <AppShell modo={modo} />;
}
