import { fold } from "@/lib/utils";
import { isDueToday, isOverdue, isPastDay, isUpcoming } from "./dates";
import type { Category, Reminder, ViewId } from "./types";

export const VIEW_LABELS: Record<ViewId, string> = {
  today: "Hoy",
  upcoming: "Próximos",
  overdue: "Atrasados",
  completed: "Hechos",
  all: "Todos",
};

export function roots(categories: Category[]): Category[] {
  return categories.filter((c) => !c.parentId);
}

export function childrenOf(categories: Category[], parentId: string): Category[] {
  return categories.filter((c) => c.parentId === parentId);
}

export function findCategory(categories: Category[], id: string): Category | undefined {
  return categories.find((c) => c.id === id);
}

export function descendantIds(categories: Category[], id: string): string[] {
  const ids = [id];
  for (const child of childrenOf(categories, id)) {
    ids.push(...descendantIds(categories, child.id));
  }
  return ids;
}

export function matchesView(reminder: Reminder, view: ViewId, now = new Date()): boolean {
  const due = reminder.dueAt;
  switch (view) {
    case "today":
      return !reminder.completedAt && isDueToday(due);
    case "upcoming":
      return !reminder.completedAt && isUpcoming(due, now);
    case "overdue":
      return !reminder.completedAt && isPastDay(due, now);
    case "completed":
      return Boolean(reminder.completedAt);
    case "all":
      return true;
  }
}

export function filterReminders(
  reminders: Reminder[],
  categories: Category[],
  opts: { view: ViewId; categoryId: string | null; search: string; now?: Date },
): Reminder[] {
  const q = fold(opts.search);
  const scope = opts.categoryId ? descendantIds(categories, opts.categoryId) : null;
  return reminders
    .filter((r) => (q ? true : matchesView(r, opts.view, opts.now)))
    .filter((r) => (scope ? scope.includes(r.categoryId) : true))
    .filter((r) => {
      if (!q) return true;
      return fold(r.title).includes(q) || fold(r.notes).includes(q);
    })
    .sort((a, b) => {
      if (!!a.completedAt !== !!b.completedAt) return a.completedAt ? 1 : -1;
      return new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime();
    });
}

export function counts(
  reminders: Reminder[],
  now = new Date(),
): Record<ViewId, number> {
  return {
    today: reminders.filter((r) => matchesView(r, "today", now)).length,
    upcoming: reminders.filter((r) => matchesView(r, "upcoming", now)).length,
    overdue: reminders.filter((r) => matchesView(r, "overdue", now)).length,
    completed: reminders.filter((r) => matchesView(r, "completed", now)).length,
    all: reminders.length,
  };
}

export function categoryCount(
  reminders: Reminder[],
  categories: Category[],
  categoryId: string,
): number {
  const scope = descendantIds(categories, categoryId);
  return reminders.filter((r) => scope.includes(r.categoryId) && !r.completedAt).length;
}

export const PRIORITY_LABELS = {
  low: "Baja",
  medium: "Media",
  high: "Alta",
} as const;

export function leaves(categories: Category[]): Category[] {
  return categories.filter((c) => childrenOf(categories, c.id).length === 0);
}
