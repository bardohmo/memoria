import {
  addDays,
  addHours,
  format,
  isBefore,
  isSameDay,
  isToday,
  isTomorrow,
  isYesterday,
  startOfDay,
} from "date-fns";
import { es } from "date-fns/locale";

const pad = (n: number) => String(n).padStart(2, "0");

export function toDatetimeLocal(iso: string): string {
  const d = new Date(iso);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function fromDatetimeLocal(value: string): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return new Date().toISOString();
  return d.toISOString();
}

export function nextHourIso(): string {
  const d = new Date();
  d.setMinutes(0, 0, 0);
  return addHours(d, 1).toISOString();
}

export function setTimeToday(hours: number, minutes = 0): string {
  const d = new Date();
  d.setHours(hours, minutes, 0, 0);
  if (d.getTime() < Date.now()) d.setDate(d.getDate() + 1);
  return d.toISOString();
}

export function headingDate(now = new Date()): string {
  const raw = format(now, "EEEE d 'de' MMMM", { locale: es });
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export function dayKey(iso: string): string {
  return format(new Date(iso), "yyyy-MM-dd");
}

export function dayLabel(iso: string, now = new Date()): string {
  const d = new Date(iso);
  if (isToday(d)) return "Hoy";
  if (isTomorrow(d)) return "Mañana";
  if (isYesterday(d)) return "Ayer";
  if (isSameDay(d, addDays(now, 2))) {
    return format(d, "EEEE", { locale: es });
  }
  return format(d, "EEEE d 'de' MMMM", { locale: es });
}

export function whenLong(iso: string): string {
  const raw = format(new Date(iso), "EEEE d 'de' MMMM yyyy · h:mm a", { locale: es });
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export function timeLabel(iso: string): string {
  return format(new Date(iso), "h:mm a", { locale: es });
}

export function isOverdue(iso: string, completedAt: string | null, now = new Date()): boolean {

  if (completedAt) return false;
  return isBefore(new Date(iso), now);
}

export function isPastDay(iso: string, now = new Date()): boolean {
  return isBefore(startOfDay(new Date(iso)), startOfDay(now));
}

export function isDueToday(iso: string): boolean {
  return isToday(new Date(iso));
}

export function isUpcoming(iso: string, now = new Date()): boolean {
  return startOfDay(new Date(iso)).getTime() > startOfDay(now).getTime();
}
