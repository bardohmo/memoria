import { ArrowRight, Bell, ChartNoAxesColumn, LayoutList } from "lucide-react";

export type SplashAction = "remember" | "organize" | "achieve" | "start";

const FEATS: {
  action: SplashAction;
  title: string;
  line: string;
  icon: typeof Bell;
  tone: "is-cyan" | "is-magenta" | "is-orange";
  label: string;
  href: string;
}[] = [
  {
    action: "remember",
    title: "Recuerda",
    line: "lo importante",
    icon: Bell,
    tone: "is-cyan",
    label: "Recuerda: abrir avisos de hoy y atrasados",
    href: "/app?modo=remember",
  },
  {
    action: "organize",
    title: "Organiza",
    line: "tus ideas",
    icon: LayoutList,
    tone: "is-magenta",
    label: "Organiza: desplegar categorías en el mapa mental",
    href: "/app?modo=organize",
  },
  {
    action: "achieve",
    title: "Logra",
    line: "tus metas",
    icon: ChartNoAxesColumn,
    tone: "is-orange",
    label: "Logra: ver próximos avisos y metas",
    href: "/app?modo=achieve",
  },
];

function go(path: string) {
  window.location.assign(path);
}

export function SplashScreen() {
  return (
    <div
      className="splash"
      onPointerUp={(event) => {
        if (event.button !== 0) return;
        const target = event.target as HTMLElement | null;
        if (target?.closest("a")) return;
        go("/app");
      }}
    >
      <div className="splash-frame">
        <header className="splash-topline">
          <p>
            Ideas
            <br />
            planes
            <br />
            tareas
            <br />
            <span>siempre contigo</span>
          </p>
          <p className="is-end">
            Una mente
            <br />
            más
            <br />
            organizada
            <br />
            <span>hoy</span>
          </p>
        </header>

        <a href="/app" className="splash-hero" aria-label="Comenzar y desplegar la mente">
          <svg viewBox="0 0 100 100" className="splash-rings" aria-hidden>
            <circle cx="50" cy="50" r="46" className="halo-ring" />
            <path d="M 18 74 A 42 42 0 0 1 24 22" className="arc-cyan" />
            <path d="M 70 14 A 42 42 0 0 1 88 60" className="arc-pink" />
            <circle cx="18" cy="72" r="2.4" className="dot-cyan" />
            <circle cx="84" cy="20" r="2.4" className="dot-pink" />
          </svg>
          <span className="splash-core" aria-hidden>
            <img src="/nucleus-brain.png?v=3" alt="" className="nucleus-brain" />
          </span>
        </a>

        <div className="splash-copy">
          <h1>
            <img src="/memoria-wordmark.png" alt="Memoria" className="splash-wordmark" />
          </h1>
          <p className="splash-tag">Recordatorios para una vida más clara</p>
          <span className="splash-rule" aria-hidden />
        </div>

        <a
          href="/app"
          className="btn-cta splash-cta"
          onClick={() => go("/app")}
        >
          Comenzar
          <ArrowRight />
        </a>

        <ul className="splash-feats">
          {FEATS.map((feat) => {
            const Icon = feat.icon;
            return (
              <li key={feat.action}>
                <a href={feat.href} className="feat-btn" aria-label={feat.label}>
                  <span className={`feat-icon ${feat.tone}`}>
                    <Icon />
                  </span>
                  <p>
                    <strong>{feat.title}</strong>
                    {feat.line}
                  </p>
                </a>
              </li>
            );
          })}
        </ul>

        <p className="splash-foot">
          Pequeños recordatorios
          <br />
          grandes cambios
        </p>
      </div>
    </div>
  );
}
