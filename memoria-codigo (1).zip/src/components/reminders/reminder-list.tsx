import { CalendarClock, Inbox } from "lucide-react";
import { dayKey, dayLabel } from "@/lib/reminders/dates";
import type { Category, Reminder } from "@/lib/reminders/types";
import { ReminderCard } from "./reminder-card";

type Props = {
  reminders: Reminder[];
  categories: Category[];
  emptyTitle: string;
  emptyBody: string;
  onToggle: (id: string) => void;
  onEdit: (reminder: Reminder) => void;
  onDelete: (reminder: Reminder) => void;
};

export function ReminderList({
  reminders,
  categories,
  emptyTitle,
  emptyBody,
  onToggle,
  onEdit,
  onDelete,
}: Props) {
  if (reminders.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl bg-card px-6 py-16 text-center shadow-card">
        <Inbox className="size-8 text-muted-foreground" strokeWidth={1.5} />
        <p className="mt-4 font-display text-xl font-medium tracking-tight">{emptyTitle}</p>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{emptyBody}</p>
      </div>
    );
  }

  const groups: { key: string; label: string; items: Reminder[] }[] = [];
  for (const reminder of reminders) {
    const key = dayKey(reminder.dueAt);
    const last = groups[groups.length - 1];
    if (last && last.key === key) {
      last.items.push(reminder);
    } else {
      groups.push({ key, label: dayLabel(reminder.dueAt), items: [reminder] });
    }
  }

  let index = 0;
  return (
    <div className="flex flex-col gap-6">
      {groups.map((group) => (
        <section key={group.key} className="flex flex-col gap-3">
          <header className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <CalendarClock className="size-3.5" />
            <h2>{group.label}</h2>
            <span className="tabular-nums">({group.items.length})</span>
          </header>
          <div className="flex flex-col gap-2">
            {group.items.map((reminder) => {
              const i = index++;
              return (
                <ReminderCard
                  key={reminder.id}
                  reminder={reminder}
                  category={categories.find((c) => c.id === reminder.categoryId)}
                  onToggle={onToggle}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  index={i}
                />
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
