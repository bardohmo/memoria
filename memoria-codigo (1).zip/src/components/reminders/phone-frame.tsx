import { createContext, useContext, useState, type ReactNode } from "react";
import { Wallpaper } from "./wallpaper";

const PhoneRootContext = createContext<HTMLElement | null>(null);

export function PhoneFrame({ children }: { children: ReactNode }) {
  const [root, setRoot] = useState<HTMLElement | null>(null);

  return (
    <div ref={setRoot} className="phone-shell">
      <Wallpaper />
      <PhoneRootContext.Provider value={root}>{children}</PhoneRootContext.Provider>
    </div>
  );
}

export function usePhoneRoot() {
  return useContext(PhoneRootContext);
}
