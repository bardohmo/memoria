import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Menu, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { findCategory, VIEW_LABELS } from "@/lib/reminders/query";
import { useReminderStore } from "@/lib/reminders/store";
import type { Reminder as ReminderItem, Category } from "@/lib/reminders/types";
import type { SplashAction } from "./splash-screen";
import { CategoryForm } from "./category-form";
import { ClusterMap } from "./cluster-map";
import { NavPanel } from "./nav-panel";
import { NotificationBell } from "./notifications";
import { PhoneFrame } from "./phone-frame";
import { ReminderForm } from "./reminder-form";

type Props = {
  modo?: SplashAction;
};

function applyModo(action: SplashAction) {
  const { setView, setCategoryId } = useReminderStore.getState();
  setCategoryId(null);
  if (action === "remember") setView("today");
  else if (action === "achieve") setView("upcoming");
  else setView("all");
}

export function AppShell({ modo = "start" }: Props) {
  const reminders = useReminderStore((s) => s.reminders);
  const categories = useReminderStore((s) => s.categories);
  const categoryId = useReminderStore((s) => s.categoryId);
  const view = useReminderStore((s) => s.view);
  const setCategoryId = useReminderStore((s) => s.setCategoryId);
  const deleteReminder = useReminderStore((s) => s.deleteReminder);
  const moveCategory = useReminderStore((s) => s.moveCategory);

  const [menuOpen, setMenuOpen] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ReminderItem | null>(null);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [pendingDelete, setPendingDelete] = useState<ReminderItem | null>(null);
  const [mindOpen, setMindOpen] = useState(false);
  const [parentForNew, setParentForNew] = useState<string | null>(null);
  const enterLock = useRef(0);

  useLayoutEffect(() => {
    applyModo(modo);
  }, [modo]);

  useEffect(() => {
    let live = true;
    void Promise.resolve(useReminderStore.persist.rehydrate()).then(() => {
      if (!live) return;
      applyModo(modo);
    });
    return () => {
      live = false;
    };
  }, [modo]);

  const focus = useMemo(
    () => (categoryId ? findCategory(categories, categoryId) : undefined),
    [categories, categoryId],
  );
  const parent = focus?.parentId ? findCategory(categories, focus.parentId) : undefined;

  function openNew() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(reminder: ReminderItem) {
    setEditing(reminder);
    setFormOpen(true);
  }

  function openNewCategory(parentId: string | null = null) {
    setEditingCategory(null);
    setParentForNew(parentId);
    setCategoryOpen(true);
  }

  function confirmDelete() {
    if (!pendingDelete) return;
    deleteReminder(pendingDelete.id);
    toast("Recordatorio eliminado");
    setPendingDelete(null);
  }

  const status = !mindOpen
    ? "Las categorías giran alrededor del centro"
    : focus
      ? parent
        ? `${parent.name} · ${focus.name}`
        : `${focus.name} · mantén pulsado para mover`
      : "Toca una categoría · o el centro para orbitar";

  return (
    <PhoneFrame>
      <div className="mind-app">
        <ClusterMap
          categories={categories}
          reminders={reminders}
          selectedId={categoryId}
          expanded={mindOpen}
          view={view}
          onToggle={() => {
            if (Date.now() < enterLock.current) return;
            if (mindOpen) {
              setCategoryId(null);
              setMindOpen(false);
              return;
            }
            setCategoryId(null);
            setMindOpen(true);
          }}
          onSelect={(id) => {
            setMindOpen(true);
            setCategoryId(id);
          }}
          onOpenReminder={openEdit}
          onCreate={openNew}
          onMove={moveCategory}
        >
          <header className="mind-hud">
            <Button
              variant="ghost"
              size="icon"
              className="hud-quiet"
              onClick={() => setMenuOpen(true)}
              aria-label="Abrir menú"
            >
              <Menu />
            </Button>
            <div className="min-w-0 flex-1">
              <p className="font-display text-lg font-semibold tracking-tight">Memoria</p>
              <p className="truncate text-xs opacity-70">{status}</p>
            </div>
            <span className="view-chip">{VIEW_LABELS[view]}</span>
            <NotificationBell />
            <Button onClick={openNew} className="btn-cta shrink-0" size="icon" aria-label="Nuevo aviso">
              <Plus />
            </Button>
          </header>

          <div className="mind-crumb">
            {focus ? (
              <Button
                size="sm"
                variant="ghost"
                className="crumb-chip"
                onClick={() => {
                  setEditingCategory(focus);
                  setParentForNew(focus.parentId);
                  setCategoryOpen(true);
                }}
              >
                Editar {focus.name}
              </Button>
            ) : null}
            {focus && !focus.parentId ? (
              <Button
                size="sm"
                variant="ghost"
                className="crumb-chip"
                onClick={() => openNewCategory(focus.id)}
              >
                Nueva subcategoría
              </Button>
            ) : null}
            {focus?.parentId ? (
              <Button size="sm" variant="ghost" className="crumb-chip" onClick={openNew}>
                Aviso en {focus.name}
              </Button>
            ) : null}
          </div>
        </ClusterMap>

        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetContent side="left">
            <SheetHeader>
              <SheetTitle className="sr-only">Menú</SheetTitle>
            </SheetHeader>
            <NavPanel
              onNewCategory={() => openNewCategory(null)}
              onEditCategory={(category) => {
                setEditingCategory(category);
                setParentForNew(category.parentId);
                setCategoryOpen(true);
              }}
              onNavigate={() => {
                setMenuOpen(false);
                setMindOpen(true);
              }}
            />
          </SheetContent>
        </Sheet>

        <ReminderForm
          open={formOpen}
          onOpenChange={(open) => {
            setFormOpen(open);
            if (!open) setEditing(null);
          }}
          reminder={editing}
          preferCategoryId={categoryId}
          onDelete={(item) => {
            setFormOpen(false);
            setPendingDelete(item);
          }}
        />
        <CategoryForm
          open={categoryOpen}
          onOpenChange={(open) => {
            setCategoryOpen(open);
            if (!open) {
              setEditingCategory(null);
              setParentForNew(null);
            }
          }}
          category={editingCategory}
          defaultParentId={parentForNew}
        />

        <AlertDialog open={Boolean(pendingDelete)} onOpenChange={(o) => !o && setPendingDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Eliminar recordatorio</AlertDialogTitle>
              <AlertDialogDescription>
                {pendingDelete
                  ? `Se eliminará “${pendingDelete.title}”. Esta acción no se puede deshacer.`
                  : ""}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:opacity-90"
                onClick={confirmDelete}
              >
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </PhoneFrame>
  );
}
