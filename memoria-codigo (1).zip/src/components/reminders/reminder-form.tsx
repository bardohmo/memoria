import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Film, ImagePlus, Mic, Pencil, Square, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  fromDatetimeLocal,
  isOverdue,
  nextHourIso,
  setTimeToday,
  toDatetimeLocal,
  whenLong,
} from "@/lib/reminders/dates";
import { swatch } from "@/lib/reminders/palette";
import { childrenOf, findCategory, leaves, PRIORITY_LABELS, roots } from "@/lib/reminders/query";
import { useReminderStore } from "@/lib/reminders/store";
import { encodeMediaFile, encodeVoiceBlob, MAX_REMINDER_MEDIA, mediaOf } from "@/lib/reminders/media";
import type { Priority, Reminder, ReminderMedia } from "@/lib/reminders/types";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reminder?: Reminder | null;
  preferCategoryId?: string | null;
  onDelete?: (reminder: Reminder) => void;
};

export function ReminderForm({ open, onOpenChange, reminder, preferCategoryId, onDelete }: Props) {
  const categories = useReminderStore((s) => s.categories);
  const addReminder = useReminderStore((s) => s.addReminder);
  const updateReminder = useReminderStore((s) => s.updateReminder);
  const toggleComplete = useReminderStore((s) => s.toggleComplete);
  const liveReminder = useReminderStore((s) =>
    reminder ? (s.reminders.find((r) => r.id === reminder.id) ?? reminder) : null,
  );
  const defaultCategory = useMemo(() => {
    const leafCats = leaves(categories);
    if (preferCategoryId) {
      if (leafCats.some((c) => c.id === preferCategoryId)) return preferCategoryId;
      const kids = childrenOf(categories, preferCategoryId);
      if (kids[0]) return kids[0].id;
    }
    return leafCats[0]?.id ?? "";
  }, [preferCategoryId, categories]);

  const [drafting, setDrafting] = useState(false);
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [categoryId, setCategoryId] = useState(defaultCategory);
  const [dueLocal, setDueLocal] = useState(toDatetimeLocal(nextHourIso()));
  const [priority, setPriority] = useState<Priority>("medium");
  const [media, setMedia] = useState<ReminderMedia[]>([]);
  const [busyMedia, setBusyMedia] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recMs, setRecMs] = useState(0);
  const [error, setError] = useState("");
  const photoInput = useRef<HTMLInputElement>(null);
  const videoInput = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const recTimer = useRef<number>(0);

  useEffect(() => {
    if (!open) return;
    setDrafting(!reminder);
    if (reminder) {
      setTitle(reminder.title);
      setNotes(reminder.notes);
      setCategoryId(reminder.categoryId);
      setDueLocal(toDatetimeLocal(reminder.dueAt));
      setPriority(reminder.priority);
      setMedia(mediaOf(reminder.media));
    } else {
      setTitle("");
      setNotes("");
      setCategoryId(defaultCategory);
      setDueLocal(toDatetimeLocal(nextHourIso()));
      setPriority("medium");
      setMedia([]);
    }
    setError("");
  }, [open, reminder, defaultCategory]);

  useEffect(() => {
    if (open) return;
    stopVoice(true);
  }, [open]);

  useEffect(() => () => stopVoice(true), []);

  const presets = useMemo(
    () => [
      { label: "En 1 hora", value: () => toDatetimeLocal(new Date(Date.now() + 60 * 60 * 1000).toISOString()) },
      { label: "Esta tarde", value: () => toDatetimeLocal(setTimeToday(18, 0)) },
      { label: "Mañana 9:00", value: () => {
        const d = new Date();
        d.setDate(d.getDate() + 1);
        d.setHours(9, 0, 0, 0);
        return toDatetimeLocal(d.toISOString());
      } },
    ],
    [],
  );

  const viewing = Boolean(reminder) && !drafting;
  const current = liveReminder ?? reminder;
  const category = current ? findCategory(categories, current.categoryId) : undefined;
  const parentCat = category?.parentId ? findCategory(categories, category.parentId) : undefined;
  const overdue = current ? isOverdue(current.dueAt, current.completedAt) : false;
  const attended = Boolean(current?.completedAt);

  function fillFrom(source: Reminder) {
    setTitle(source.title);
    setNotes(source.notes);
    setCategoryId(source.categoryId);
    setDueLocal(toDatetimeLocal(source.dueAt));
    setPriority(source.priority);
    setMedia(mediaOf(source.media));
    setError("");
  }

  function cancelDraft() {
    if (reminder) {
      fillFrom(reminder);
      setDrafting(false);
      return;
    }
    onOpenChange(false);
  }

  async function addFiles(list: FileList | null) {
    if (!list?.length) return;
    const room = MAX_REMINDER_MEDIA - media.length;
    if (room <= 0) {
      toast("Puedes adjuntar hasta 6 archivos por aviso.");
      return;
    }
    setBusyMedia(true);
    try {
      const incoming = Array.from(list).slice(0, room);
      const next: ReminderMedia[] = [];
      for (const file of incoming) {
        next.push(await encodeMediaFile(file));
      }
      setMedia((prev) => [...prev, ...next]);
    } catch (err) {
      toast(err instanceof Error ? err.message : "No se pudo adjuntar el archivo.");
    } finally {
      setBusyMedia(false);
      if (photoInput.current) photoInput.current.value = "";
      if (videoInput.current) videoInput.current.value = "";
    }
  }

  function onPick(e: ChangeEvent<HTMLInputElement>) {
    void addFiles(e.target.files);
  }

  function releaseMic() {
    window.clearInterval(recTimer.current);
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    recorderRef.current = null;
    setRecording(false);
    setRecMs(0);
  }

  function stopVoice(discard = false) {
    const rec = recorderRef.current;
    if (!rec || rec.state === "inactive") {
      releaseMic();
      return;
    }
    if (discard) {
      rec.ondataavailable = null;
      rec.onstop = null;
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
      releaseMic();
      return;
    }
    rec.stop();
  }

  async function startVoice() {
    if (media.length >= MAX_REMINDER_MEDIA) {
      toast("Puedes adjuntar hasta 6 archivos por aviso.");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      toast("Este dispositivo no permite grabar voz.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"].find((type) =>
        MediaRecorder.isTypeSupported(type),
      );
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (event) => {
        if (event.data.size) chunksRef.current.push(event.data);
      };
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        releaseMic();
        setBusyMedia(true);
        void encodeVoiceBlob(blob)
          .then((item) => setMedia((prev) => [...prev, item]))
          .catch((err) => {
            toast(err instanceof Error ? err.message : "No se pudo guardar la nota de voz.");
          })
          .finally(() => setBusyMedia(false));
      };
      recorderRef.current = rec;
      rec.start();
      setRecording(true);
      const started = Date.now();
      recTimer.current = window.setInterval(() => {
        const elapsed = Date.now() - started;
        setRecMs(elapsed);
        if (elapsed >= 45_000) stopVoice();
      }, 200);
    } catch {
      releaseMic();
      toast("No se pudo usar el micrófono.");
    }
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setError("Escribe un título para el recordatorio.");
      return;
    }
    if (!categoryId) {
      setError("Crea una categoría primero.");
      return;
    }
    const draft = {
      title,
      notes,
      categoryId,
      dueAt: fromDatetimeLocal(dueLocal),
      priority,
      media,
    };
    if (reminder) {
      updateReminder(reminder.id, draft);
      toast("Recordatorio actualizado");
    } else {
      addReminder(draft);
      toast("Recordatorio guardado");
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        {viewing && current ? (
          <div className="grid gap-5">
            <DialogHeader>
              <DialogTitle>{current.title}</DialogTitle>
              <DialogDescription>
                {attended
                  ? "Este aviso está atendido. Puedes editarlo o volver a marcarlo."
                  : "Solo lectura. Pulsa Editar para cambiarlo."}
              </DialogDescription>
            </DialogHeader>

            <div className="flex flex-wrap gap-2">
              <Badge variant={attended ? "success" : "outline"}>
                {attended ? "Atendido" : "No atendido"}
              </Badge>
              {overdue && !attended ? <Badge variant="overdue">Atrasado</Badge> : null}
              <Badge variant={current.priority === "high" ? "high" : "default"}>
                {PRIORITY_LABELS[current.priority]}
              </Badge>
            </div>

            <p className="text-sm leading-relaxed text-foreground">
              {current.notes.trim() ? current.notes : "Sin notas."}
            </p>

            {mediaOf(current.media).length ? (
              <div className="grid gap-2">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Adjuntos
                </p>
                <div className="media-grid">
                  {mediaOf(current.media).map((item) =>
                    item.kind === "video" ? (
                      <video
                        key={item.id}
                        className="media-tile is-video"
                        src={item.src}
                        controls
                        playsInline
                        preload="metadata"
                        aria-label={item.name}
                      />
                    ) : item.kind === "voice" ? (
                      <div key={item.id} className="media-tile is-voice">
                        <audio src={item.src} controls preload="metadata" />
                        <span>Nota de voz</span>
                      </div>
                    ) : (
                      <img
                        key={item.id}
                        className="media-tile"
                        src={item.src}
                        alt={item.name}
                      />
                    ),
                  )}
                </div>
              </div>
            ) : null}

            <div className="grid gap-3 rounded-md bg-muted p-4">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Estado</p>
                <p className="mt-1 text-sm">{attended ? "Atendido" : "No atendido"}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Cuándo</p>
                <p className="mt-1 text-sm">{whenLong(current.dueAt)}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Categoría</p>
                <p className="mt-1 flex items-center gap-2 text-sm">
                  {category ? (
                    <>
                      <span
                        className="size-2.5 rounded-full"
                        style={{ backgroundColor: swatch(category.color) }}
                        aria-hidden
                      />
                      {parentCat ? `${parentCat.name} · ${category.name}` : category.name}
                    </>
                  ) : (
                    "Sin categoría"
                  )}
                </p>
              </div>
            </div>

            <Button
              type="button"
              variant="secondary"
              onClick={() => toggleComplete(current.id)}
            >
              {attended ? "Marcar no atendido" : "Marcar atendido"}
            </Button>

            <DialogFooter className="flex-row justify-end gap-2 sm:flex-row">
              <Button
                type="button"
                variant="destructive"
                onClick={() => onDelete?.(current)}
              >
                <Trash2 />
                Eliminar
              </Button>
              <Button type="button" onClick={() => setDrafting(true)}>
                <Pencil />
                Editar
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <form onSubmit={submit} className="grid gap-5">
            <DialogHeader>
              <DialogTitle>{reminder ? "Editar recordatorio" : "Nuevo recordatorio"}</DialogTitle>
              <DialogDescription>
                {reminder
                  ? "Ajusta el título, la hora o la subcategoría."
                  : "El aviso se guarda en una subcategoría del mapa."}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-2">
              <Label htmlFor="reminder-title">Título</Label>
              <Input
                id="reminder-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Qué hay que recordar"
                autoFocus
              />
              {error ? <p className="text-sm text-destructive">{error}</p> : null}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="reminder-notes">Notas</Label>
              <Textarea
                id="reminder-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Detalles opcionales"
                rows={3}
              />
            </div>

            <div className="grid gap-2">
              <Label>Fotos, videos y voz</Label>
              <p className="text-xs text-muted-foreground">
                Se muestran solo al abrir este recordatorio.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  disabled={busyMedia || recording || media.length >= MAX_REMINDER_MEDIA}
                  onClick={() => photoInput.current?.click()}
                >
                  <ImagePlus />
                  Subir foto
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  disabled={busyMedia || recording || media.length >= MAX_REMINDER_MEDIA}
                  onClick={() => videoInput.current?.click()}
                >
                  <Film />
                  Subir video
                </Button>
                <Button
                  type="button"
                  variant={recording ? "destructive" : "secondary"}
                  disabled={busyMedia || (!recording && media.length >= MAX_REMINDER_MEDIA)}
                  onClick={() => (recording ? stopVoice() : void startVoice())}
                >
                  {recording ? <Square /> : <Mic />}
                  {recording ? `Detener ${Math.floor(recMs / 1000)}s` : "Grabar voz"}
                </Button>
              </div>
              <input
                ref={photoInput}
                id="reminder-photo"
                className="sr-only"
                type="file"
                accept="image/*"
                multiple
                onChange={onPick}
              />
              <input
                ref={videoInput}
                id="reminder-video"
                className="sr-only"
                type="file"
                accept="video/*"
                multiple
                onChange={onPick}
              />
              {media.length ? (
                <div className="media-grid is-edit">
                  {media.map((item) => (
                    <div key={item.id} className={cn("media-edit", item.kind !== "photo" && `is-${item.kind}`)}>
                      {item.kind === "video" ? (
                        <video src={item.src} muted playsInline preload="metadata" />
                      ) : item.kind === "voice" ? (
                        <audio src={item.src} controls preload="metadata" />
                      ) : (
                        <img src={item.src} alt={item.name} />
                      )}
                      {item.kind === "voice" ? <span className="voice-label">Nota de voz</span> : null}
                      <button
                        type="button"
                        className="media-remove"
                        aria-label={`Quitar ${item.name}`}
                        onClick={() => setMedia((prev) => prev.filter((m) => m.id !== item.id))}
                      >
                        <X />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  {busyMedia ? "Procesando archivo…" : "Ningún archivo adjunto."}
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="reminder-due">Fecha y hora</Label>
              <Input
                id="reminder-due"
                type="datetime-local"
                value={dueLocal}
                onChange={(e) => setDueLocal(e.target.value)}
              />
              <div className="flex flex-wrap gap-2">
                {presets.map((p) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => setDueLocal(p.value())}
                    className="h-9 rounded-full bg-secondary px-3 text-xs font-medium text-secondary-foreground transition-[background-color] duration-[var(--motion-quick)] hover:bg-muted"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid gap-3">
              <Label>Subcategoría</Label>
              {roots(categories).map((root) => {
                const kids = childrenOf(categories, root.id);
                const options = kids.length ? kids : [root];
                return (
                  <div key={root.id} className="grid gap-2">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                      {root.name}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {options.map((c) => {
                        const selected = c.id === categoryId;
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => setCategoryId(c.id)}
                            className={cn(
                              "flex h-11 items-center gap-2 rounded-full px-3 text-sm font-medium transition-[background-color,box-shadow] duration-[var(--motion-quick)]",
                              selected
                                ? "bg-primary text-primary-foreground"
                                : "bg-secondary text-secondary-foreground",
                            )}
                          >
                            <span
                              className="size-2.5 rounded-full"
                              style={{ backgroundColor: selected ? "currentColor" : swatch(c.color) }}
                              aria-hidden
                            />
                            {c.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="grid gap-2">
              <Label>Prioridad</Label>
              <div className="grid grid-cols-3 gap-2">
                {(["low", "medium", "high"] as const).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={cn(
                      "h-11 rounded-md text-sm font-medium transition-[background-color] duration-[var(--motion-quick)]",
                      priority === p
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground",
                    )}
                  >
                    {PRIORITY_LABELS[p]}
                  </button>
                ))}
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={cancelDraft}>
                Cancelar
              </Button>
              <Button type="submit">{reminder ? "Guardar cambios" : "Crear recordatorio"}</Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
