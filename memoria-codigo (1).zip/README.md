# Memoria

Recordatorios en un mapa mental. Categorías orbitan un cerebro central; tocas, despliegas subcategorías y abres avisos con fotos, video o nota de voz.

## Uso

1. Toca **Comenzar**.
2. Toca el cerebro para ordenar las categorías.
3. Elige una categoría y una subcategoría para ver o crear recordatorios.
4. Mantén pulsado un círculo para moverlo.

Los avisos, fotos y notas de voz se guardan en este dispositivo.

## Desarrollo

```bash
npm install
npm run dev
```

Abre `http://localhost:8080`.
