import { MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { isOverdue, timeLabel } from "@/lib/reminders/dates";
import { swatch } from "@/lib/reminders/palette";
import { PRIORITY_LABELS } from "@/lib/reminders/query";
import type { Category, Reminder } from "@/lib/reminders/types";

type Props = {
  reminder: Reminder;
  category?: Category;
  onToggle: (id: string) => void;
  onEdit: (reminder: Reminder) => void;
  onDelete: (reminder: Reminder) => void;
  index: number;
};

export function ReminderCard({ reminder, category, onToggle, onEdit, onDelete, index }: Props) {
  const overdue = isOverdue(reminder.dueAt, reminder.completedAt);
  const done = Boolean(reminder.completedAt);

  return (
    <article
      className={cn(
        "stagger-in group relative flex gap-3 rounded-xl bg-card p-3 shadow-card",
        "transition-[box-shadow,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
        "hover:shadow-card-hover",
        done && "opacity-70",
      )}
      style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}
    >
      <span
        className="absolute inset-y-3 left-0 w-1 rounded-full"
        style={{ backgroundColor: category ? swatch(category.color) : "var(--color-border)" }}
        aria-hidden
      />
      <div className="flex items-start pt-1 pl-2">
        <Checkbox
          checked={done}
          onCheckedChange={() => onToggle(reminder.id)}
          aria-label={done ? "Marcar como pendiente" : "Marcar como hecho"}
        />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <time className="tabular-nums font-medium" dateTime={reminder.dueAt}>
            {timeLabel(reminder.dueAt)}
          </time>
          {overdue ? <Badge variant="overdue">Atrasado</Badge> : null}
          {reminder.priority === "high" && !done ? <Badge variant="high">Alta</Badge> : null}
          {done ? <Badge variant="success">Hecho</Badge> : null}
        </div>
        <h3
          className={cn(
            "mt-1 font-medium leading-snug text-foreground",
            done && "text-muted-foreground line-through",
          )}
        >
          {reminder.title}
        </h3>
        {reminder.notes ? (
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{reminder.notes}</p>
        ) : null}
        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {category ? (
            <span className="inline-flex items-center gap-1.5">
              <span
                className="size-1.5 rounded-full"
                style={{ backgroundColor: swatch(category.color) }}
              />
              {category.name}
            </span>
          ) : null}
          {reminder.priority !== "high" ? (
            <span>Prioridad {PRIORITY_LABELS[reminder.priority].toLowerCase()}</span>
          ) : null}
        </div>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon-sm" className="shrink-0" aria-label="Más acciones">
            <MoreHorizontal />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onSelect={() => onEdit(reminder)}>
            <Pencil className="size-4" />
            Editar
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem variant="destructive" onSelect={() => onDelete(reminder)}>
            <Trash2 className="size-4" />
            Eliminar
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </article>
  );
}
