import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import type { Category, PaletteId, Reminder, ReminderDraft, ViewId } from "./types";
import { addDays } from "date-fns";
import { descendantIds, roots } from "./query";

function atHour(base: Date, days: number, hours: number, minutes = 0): string {
  const d = new Date(base);
  d.setDate(d.getDate() + days);
  d.setHours(hours, minutes, 0, 0);
  return d.toISOString();
}

function seed(now = new Date()): { categories: Category[]; reminders: Reminder[] } {
  const personal = "cat-personal";
  const trabajo = "cat-trabajo";
  const salud = "cat-salud";
  const casa = "cat-casa";
  const familia = "sub-familia";
  const agenda = "sub-agenda";
  const entregas = "sub-entregas";
  const reuniones = "sub-reuniones";
  const citas = "sub-citas";
  const habitos = "sub-habitos";
  const compras = "sub-compras";
  const cuentas = "sub-cuentas";
  const createdAt = "2026-01-01T00:00:00.000Z";

  const categories: Category[] = [
    { id: personal, name: "Personal", color: "slate", parentId: null },
    { id: trabajo, name: "Trabajo", color: "ink", parentId: null },
    { id: salud, name: "Salud", color: "sage", parentId: null },
    { id: casa, name: "Casa", color: "clay", parentId: null },
    { id: familia, name: "Familia", color: "slate", parentId: personal },
    { id: agenda, name: "Agenda", color: "storm", parentId: personal },
    { id: entregas, name: "Entregas", color: "ink", parentId: trabajo },
    { id: reuniones, name: "Reuniones", color: "storm", parentId: trabajo },
    { id: citas, name: "Citas", color: "sage", parentId: salud },
    { id: habitos, name: "Hábitos", color: "olive", parentId: salud },
    { id: compras, name: "Compras", color: "clay", parentId: casa },
    { id: cuentas, name: "Cuentas", color: "cocoa", parentId: casa },
  ];

  const reminders: Reminder[] = [
    {
      id: "rem-dentista",
      title: "Llamar al dentista",
      notes: "Confirmar la cita de limpieza.",
      categoryId: citas,
      dueAt: atHour(now, 0, 16, 0),
      completedAt: null,
      priority: "medium",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-reporte",
      title: "Entregar reporte trimestral",
      notes: "Adjuntar gráficos de ventas y notas de riesgos.",
      categoryId: entregas,
      dueAt: atHour(now, 1, 10, 0),
      completedAt: null,
      priority: "high",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-compras",
      title: "Comprar leche y pan",
      notes: "",
      categoryId: compras,
      dueAt: atHour(now, 0, 18, 30),
      completedAt: null,
      priority: "low",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-mama",
      title: "Cita con mamá",
      notes: "Café en el centro a media mañana.",
      categoryId: familia,
      dueAt: atHour(now, 3, 11, 0),
      completedAt: null,
      priority: "medium",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-presupuesto",
      title: "Revisar presupuesto",
      notes: "Ajustar gastos del mes y pagos pendientes.",
      categoryId: entregas,
      dueAt: atHour(now, -1, 9, 0),
      completedAt: null,
      priority: "high",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-caminar",
      title: "Caminar 30 minutos",
      notes: "",
      categoryId: habitos,
      dueAt: atHour(now, 0, 7, 0),
      completedAt: "2026-01-01T12:00:00.000Z",
      priority: "low",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-luz",
      title: "Pagar el recibo de luz",
      notes: "Vence a fin de semana.",
      categoryId: cuentas,
      dueAt: addDays(new Date(atHour(now, 0, 12, 0)), 5).toISOString(),
      completedAt: null,
      priority: "medium",
      createdAt,
      notifiedAt: null,
      media: [],
    },
    {
      id: "rem-junta",
      title: "Junta con diseño",
      notes: "Revisar el prototipo de la app.",
      categoryId: reuniones,
      dueAt: atHour(now, 1, 16, 0),
      completedAt: null,
      priority: "medium",
      createdAt,
      notifiedAt: null,
      media: [],
    },
  ];

  return { categories, reminders };
}

const seeded = seed();

type State = {
  categories: Category[];
  reminders: Reminder[];
  view: ViewId;
  categoryId: string | null;
  search: string;
  addReminder: (draft: ReminderDraft) => void;
  updateReminder: (id: string, draft: ReminderDraft) => void;
  toggleComplete: (id: string) => void;
  deleteReminder: (id: string) => void;
  markNotified: (id: string) => void;
  addCategory: (name: string, color: PaletteId, parentId?: string | null, image?: string | null) => string;
  updateCategory: (id: string, name: string, color: PaletteId, parentId?: string | null, image?: string | null) => void;
  deleteCategory: (id: string) => void;
  setView: (view: ViewId) => void;
  setCategoryId: (id: string | null) => void;
  setSearch: (value: string) => void;
  moveCategory: (id: string, x: number, y: number) => void;
};

export const useReminderStore = create<State>()(
  persist(
    (set, get) => ({
      categories: seeded.categories,
      reminders: seeded.reminders,
      view: "all",
      categoryId: null,
      search: "",
      addReminder: (draft) =>
        set((s) => ({
          reminders: [
            {
              id: uid(),
              title: draft.title.trim(),
              notes: draft.notes.trim(),
              categoryId: draft.categoryId,
              dueAt: draft.dueAt,
              completedAt: null,
              priority: draft.priority,
              createdAt: new Date().toISOString(),
              notifiedAt: null,
              media: draft.media ?? [],
            },
            ...s.reminders,
          ],
        })),
      updateReminder: (id, draft) =>
        set((s) => ({
          reminders: s.reminders.map((r) =>
            r.id === id
              ? {
                  ...r,
                  title: draft.title.trim(),
                  notes: draft.notes.trim(),
                  categoryId: draft.categoryId,
                  dueAt: draft.dueAt,
                  priority: draft.priority,
                  media: draft.media ?? [],
                }
              : r,
          ),
        })),
      toggleComplete: (id) =>
        set((s) => ({
          reminders: s.reminders.map((r) =>
            r.id === id
              ? { ...r, completedAt: r.completedAt ? null : new Date().toISOString() }
              : r,
          ),
        })),
      deleteReminder: (id) =>
        set((s) => ({ reminders: s.reminders.filter((r) => r.id !== id) })),
      markNotified: (id) =>
        set((s) => ({
          reminders: s.reminders.map((r) =>
            r.id === id ? { ...r, notifiedAt: new Date().toISOString() } : r,
          ),
        })),
      addCategory: (name, color, parentId = null, image = null) => {
        const id = uid();
        set((s) => ({
          categories: [
            ...s.categories,
            {
              id,
              name: name.trim(),
              color,
              parentId: parentId ?? null,
              image: image || undefined,
            },
          ],
        }));
        return id;
      },
      updateCategory: (id, name, color, parentId, image) =>
        set((s) => ({
          categories: s.categories.map((c) =>
            c.id === id
              ? {
                  ...c,
                  name: name.trim(),
                  color,
                  parentId: parentId === undefined ? c.parentId : parentId,
                  image: image === undefined ? c.image : image || undefined,
                }
              : c,
          ),
        })),
      deleteCategory: (id) => {
        const { categories, reminders, categoryId } = get();
        const removing = new Set(descendantIds(categories, id));
        const remaining = categories.filter((c) => !removing.has(c.id));
        if (roots(remaining).length === 0) return;
        const fallback =
          remaining.find((c) => remaining.every((o) => o.parentId !== c.id))?.id ??
          remaining[0]?.id;
        if (!fallback) return;
        set({
          categories: remaining,
          reminders: reminders.map((r) =>
            removing.has(r.categoryId) ? { ...r, categoryId: fallback } : r,
          ),
          categoryId: categoryId && removing.has(categoryId) ? null : categoryId,
        });
      },
      setView: (view) => set({ view }),
      setCategoryId: (id) => set({ categoryId: id }),
      setSearch: (value) => set({ search: value }),
      moveCategory: (id, x, y) =>
        set((s) => ({
          categories: s.categories.map((c) => (c.id === id ? { ...c, x, y } : c)),
        })),
    }),
    {
      name: "memoria-v1",
      partialize: (s) => ({
        categories: s.categories,
        reminders: s.reminders,
      }),
      skipHydration: true,
    },
  ),
);
