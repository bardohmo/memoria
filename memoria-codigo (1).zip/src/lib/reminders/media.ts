import { uid } from "@/lib/utils";
import type { ReminderMedia } from "./types";

export const MAX_REMINDER_MEDIA = 6;
const MAX_EDGE = 1400;
const MAX_VIDEO_BYTES = 8 * 1024 * 1024;
const MAX_VOICE_BYTES = 2.5 * 1024 * 1024;

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("No se pudo leer el archivo."));
    reader.readAsDataURL(file);
  });
}

function compressImage(file: File, maxEdge = MAX_EDGE, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(image.width, image.height));
      const width = Math.max(1, Math.round(image.width * scale));
      const height = Math.max(1, Math.round(image.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(url);
        reject(new Error("No se pudo procesar la foto."));
        return;
      }
      ctx.drawImage(image, 0, 0, width, height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("La foto no se pudo abrir."));
    };
    image.src = url;
  });
}

export async function encodeMediaFile(file: File): Promise<ReminderMedia> {
  if (file.type.startsWith("video/")) {
    if (file.size > MAX_VIDEO_BYTES) {
      throw new Error("El video es demasiado grande (máx. 8 MB).");
    }
    return {
      id: uid(),
      kind: "video",
      name: file.name || "video",
      mime: file.type || "video/mp4",
      src: await readAsDataUrl(file),
    };
  }
  if (file.type.startsWith("image/")) {
    return {
      id: uid(),
      kind: "photo",
      name: file.name || "foto",
      mime: "image/jpeg",
      src: await compressImage(file),
    };
  }
  if (file.type.startsWith("audio/")) {
    return encodeVoiceBlob(file);
  }
  throw new Error("Elige una foto, un video o una nota de voz.");
}

export async function encodeVoiceBlob(blob: Blob): Promise<ReminderMedia> {
  if (blob.size > MAX_VOICE_BYTES) {
    throw new Error("La nota de voz es demasiado larga.");
  }
  if (blob.size < 800) {
    throw new Error("La grabación quedó vacía. Inténtalo de nuevo.");
  }
  const mime = blob.type || "audio/webm";
  const file = blob instanceof File ? blob : new File([blob], "nota-de-voz.webm", { type: mime });
  return {
    id: uid(),
    kind: "voice",
    name: file.name || "Nota de voz",
    mime,
    src: await readAsDataUrl(file),
  };
}

export async function encodeCategoryImage(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Elige una foto.");
  }
  return compressImage(file, 560, 0.8);
}

export function mediaOf(list: ReminderMedia[] | undefined): ReminderMedia[] {
  return Array.isArray(list) ? list : [];
}
