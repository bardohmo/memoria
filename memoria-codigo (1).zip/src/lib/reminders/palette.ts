import type { PaletteId } from "./types";

export const PALETTE: Record<
  PaletteId,
  { label: string; swatch: `var(--cat-${PaletteId})` }
> = {
  ink: { label: "Azul", swatch: "var(--cat-ink)" },
  slate: { label: "Cian", swatch: "var(--cat-slate)" },
  sage: { label: "Aqua", swatch: "var(--cat-sage)" },
  olive: { label: "Ámbar", swatch: "var(--cat-olive)" },
  clay: { label: "Naranja", swatch: "var(--cat-clay)" },
  cocoa: { label: "Coral", swatch: "var(--cat-cocoa)" },
  rose: { label: "Magenta", swatch: "var(--cat-rose)" },
  storm: { label: "Violeta", swatch: "var(--cat-storm)" },
};

export function swatch(color: PaletteId): string {
  return PALETTE[color].swatch;
}
