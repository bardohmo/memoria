import { useEffect, useRef } from "react";

export function Wallpaper() {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => {
      if (motion.matches) {
        video.pause();
        return;
      }
      void video.play().catch(() => {
        /* autoplay may wait for a tap in some previews */
      });
    };

    sync();
    video.addEventListener("canplay", sync);
    motion.addEventListener("change", sync);
    return () => {
      video.removeEventListener("canplay", sync);
      motion.removeEventListener("change", sync);
    };
  }, []);

  return (
    <div className="app-wallpaper" aria-hidden>
      <img src="/wallpaper.jpg" alt="" className="app-wallpaper-still" />
      <video
        ref={videoRef}
        className="app-wallpaper-video"
        src="/wallpaper.mp4"
        poster="/wallpaper.jpg"
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
      />
    </div>
  );
}
