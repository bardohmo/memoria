import { useEffect, useRef, useState, type FormEvent } from "react";
import { ImagePlus, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { encodeCategoryImage } from "@/lib/reminders/media";
import { PALETTE } from "@/lib/reminders/palette";
import { roots } from "@/lib/reminders/query";
import { useReminderStore } from "@/lib/reminders/store";
import { PALETTE_IDS, type Category, type PaletteId } from "@/lib/reminders/types";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category?: Category | null;
  defaultParentId?: string | null;
};

export function CategoryForm({ open, onOpenChange, category, defaultParentId }: Props) {
  const categories = useReminderStore((s) => s.categories);
  const addCategory = useReminderStore((s) => s.addCategory);
  const updateCategory = useReminderStore((s) => s.updateCategory);
  const [name, setName] = useState("");
  const [color, setColor] = useState<PaletteId>("ink");
  const [parentId, setParentId] = useState<string | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [busyImage, setBusyImage] = useState(false);
  const [error, setError] = useState("");
  const imageInput = useRef<HTMLInputElement>(null);

  const parents = roots(categories).filter((c) => c.id !== category?.id);

  useEffect(() => {
    if (!open) return;
    setName(category?.name ?? "");
    setColor(category?.color ?? "ink");
    setParentId(category?.parentId ?? defaultParentId ?? null);
    setImage(category?.image ?? null);
    setError("");
  }, [open, category, defaultParentId]);

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      setError("Ponle un nombre.");
      return;
    }
    if (category) {
      updateCategory(category.id, name, color, parentId, image);
      toast("Categoría actualizada");
    } else {
      addCategory(name, color, parentId, image);
      toast(parentId ? "Subcategoría creada" : "Categoría creada");
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <form onSubmit={submit} className="grid gap-5">
          <DialogHeader>
            <DialogTitle>
              {category
                ? "Editar categoría"
                : parentId
                  ? "Nueva subcategoría"
                  : "Nueva categoría"}
            </DialogTitle>
            <DialogDescription>
              Las categorías viven en el córtex. Las subcategorías se despliegan al tocarlas.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="category-name">Nombre</Label>
            <Input
              id="category-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Familia, entregas, hábitos…"
              autoFocus
            />
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
          </div>
          <div className="grid gap-2">
            <Label>Imagen del círculo</Label>
            <p className="text-xs text-muted-foreground">
              Se ve dentro del círculo, con transparencia. El número se conserva.
            </p>
            <div className="flex items-center gap-3">
              {image ? (
                <span className="cat-image-preview" style={{ backgroundImage: `url(${image})` }} />
              ) : (
                <span className="cat-image-preview is-empty" />
              )}
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  disabled={busyImage}
                  onClick={() => imageInput.current?.click()}
                >
                  <ImagePlus />
                  {image ? "Cambiar foto" : "Subir foto"}
                </Button>
                {image ? (
                  <Button type="button" variant="ghost" onClick={() => setImage(null)}>
                    <X />
                    Quitar
                  </Button>
                ) : null}
              </div>
              <input
                ref={imageInput}
                className="sr-only"
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  setBusyImage(true);
                  try {
                    setImage(await encodeCategoryImage(file));
                  } catch (err) {
                    toast(err instanceof Error ? err.message : "No se pudo usar la foto.");
                  } finally {
                    setBusyImage(false);
                  }
                }}
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Pertenece a</Label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setParentId(null)}
                className={cn(
                  "h-11 rounded-full px-3 text-sm font-medium",
                  parentId === null
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground",
                )}
              >
                Categoría raíz
              </button>
              {parents.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setParentId(c.id)}
                  className={cn(
                    "h-11 rounded-full px-3 text-sm font-medium",
                    parentId === c.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground",
                  )}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Color</Label>
            <div className="grid grid-cols-4 gap-2">
              {PALETTE_IDS.map((id) => {
                const selected = color === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setColor(id)}
                    className={cn(
                      "flex h-11 items-center justify-center gap-2 rounded-md bg-secondary px-2 text-xs font-medium",
                      selected && "ring-2 ring-ring",
                    )}
                    aria-pressed={selected}
                  >
                    <span
                      className="size-2.5 rounded-full"
                      style={{ backgroundColor: PALETTE[id].swatch }}
                    />
                    {PALETTE[id].label}
                  </button>
                );
              })}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">{category ? "Guardar" : "Crear"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
